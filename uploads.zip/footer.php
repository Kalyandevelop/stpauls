<footer>
    <div class="footer-newsletter">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-7">
            <form id="newsletter-validate-detail" method="post" action="#">
              <h3 class="hidden-sm" style="font-weight:800;">Exam based MCQ questions review in system for students at <br>any convenient time between 9.30 AM - 4.30 PM</h3>
           
			 
			  
            </form>
          </div>
          <div class="social col-md-4 col-sm-5">
            <ul class="inline-mode" style="float:left">
              <li class="social-network fb"><a style="padding-top:0px;background-color:#3F729B" title="Connect us on Facebook" target="_blank" href="https://www.facebook.com/stpaulsnursescoachingcentre/"><i class="fa-brands fa-facebook"></i></a></li>
			  
			  <li class="social-network instagram"><a style="padding-top:0px; background-color:#3F729B" title="Connect us on Instagram" target="_blank" href="https://www.instagram.com/st.pauls_coaching_centre/"><i class="fa-brands fa-instagram"></i></a></li>
			  
			  
            <li class="social-network blogger"><a title="Connect us on blog" target="_blank" href="https://stpaulscoachingcentre.com/blog/" style="background-color:#3F729B"><i class="fa-brands fa-blogger"></i></a></li>
      
			  
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-sm-6 col-md-4 col-xs-12 col-lg-3">
         <!-- <div class="footer-logo"><a href="index.php"><img src="imgs/logo.png" alt="fotter logo"></a> </div>-->
          
          <div class="footer-content">
           <a href="mailto:paulscentre@gmail.com" target="_blank"> <div class="email"> <i class="fa fa-envelope"></i>
              <p>paulscentre@gmail.com</p>
            </div></a>
         <a href="tel:+91 9447104308" target="_blank"> <div class="phone"> <i class="fa fa-phone"></i>
              <p>+91 9447104308</p>	  
			  
            </div></a>
		<a href="https://wa.me/918089085309" target="_blank"> <div class="phone"> <i style="background-color:#18c80a; color :#FFF; padding:10px;" class="fa fa-whatsapp"></i>
              <p>+91 8089085309</p>	  
			  
            </div>	</a>	

			<br><br>
			 <a href="https://stpaulscoachingcentre.com/studentsfeedback.php"><button class="button subscribe" type="submit" title="">Post Your Feedback</button></a>
		
          </div>
        </div>
		
		
		<div class="col-sm-6 col-md-3 col-xs-12 col-lg-3 collapsed-block">
          <div class="footer-content">
            
			
			<div class="address"> <i class="fa fa-map-marker"></i>
              <p> St.Paul's  Coaching Centre<br>
Kolenchery Tower<br>
Near LF Hospital Entry Gate, Angamaly,Ernakulam.</p>
            </div>
			
			
			
           
          </div>
        </div> 
		
		
		
		
		<div class="col-sm-6 col-md-4 col-xs-12 col-lg-6">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3926.889280325957!2d76.38898611428323!3d10.189646172537154!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b08065c3ff3b263%3A0xed22c0e42b3d6066!2sKolenchery%20Towers%2C%20East%20Nagar%2C%20Angamaly%2C%20Kerala%20683572!5e0!3m2!1sen!2sin!4v1639463283280!5m2!1sen!2sin" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
		
		
		
		
      </div>
    </div>
    <div class="footer-coppyright">
      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-xs-12 coppyright"> Copyright © 2022 <a href="#"> MOH </a>. All Rights Reserved. </div> <div class="col-sm-6 col-xs-12" align="right"> <span style="font-color:#efefef;font-size:11px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Powered by <a href="https://assetss.in" target="_blank">Asset Software Solutions</a></span></div>
      
		  
        </div>
      </div>
    </div>
  </footer>