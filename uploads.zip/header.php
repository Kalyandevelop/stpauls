
<div class="pre-header">
        <div class="socialr align-middle">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">


                    <span><a href=""><i class="fa-solid fa-phone"></i> 91 94471 04308</a>&nbsp;&nbsp; <a href=""><i class="fa-brands fa-whatsapp"></i> 91 80890 85309</a> &nbsp;&nbsp;<i class="fa-solid fa-envelope pad" ></i> paulscentre@gmail.com</a></span>
                     
                    </div>
                    <div class="col-md-6 visible-lg">
                        <p class="fade-in-out">DATAFLOW FOR ALL HEALTH CARE PROFESSIONALS</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="header">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="logo">
                    <img src="imgs/logo.png" alt="" style="width:100%;height:auto">
                    </div>
                    
                </div>
                <div class="col-md-8">
                <h4 class="text-right" style=" border: 2px dashed #24bb06; padding:10px;" >
		 
         <center><a href="https://www.stpaulscoachingcentre.com/courseoffered/haad.php">HAAD</a>, <a href="https://www.stpaulscoachingcentre.com/courseoffered/moh.php">MOH</a>, <a href="https://www.stpaulscoachingcentre.com/courseoffered/dha.php">DHA</a>, <a href="https://www.stpaulscoachingcentre.com/courseoffered/prometric.php">PROMETRIC</a> (SAUDI, OMAN , QATAR, KUWAIT, BAHRAIN) <br> 
         <a href="https://www.stpaulscoachingcentre.com/courseoffered/cbt.php">CBT-UK</a>, <a href="https://www.stpaulscoachingcentre.com/courseoffered/nclex-rn.php">NCLEX-RN</a>, <a href="https://www.stpaulscoachingcentre.com/courseoffered/psc.php">PSC</a>, <a href="https://www.stpaulscoachingcentre.com/courseoffered/aiims.php">AIIMS</a>, <a href="https://www.stpaulscoachingcentre.com/courseoffered/jipmer.php">JIPMER</a><br> 		
         <a href="https://www.stpaulscoachingcentre.com/courseoffered/acls.php">ACLS</a>, <a href="https://www.stpaulscoachingcentre.com/courseoffered/bls.php">BLS</a>,
     <a href="https://www.stpaulscoachingcentre.com/courseoffered/pscpharmacy.php">PSC-PHARMACY</a>,
     <a href="https://www.stpaulscoachingcentre.com/courseoffered/pscmicrobiology.php">PSC-MICROBIOLOGY</a>,
     <a href="https://www.stpaulscoachingcentre.com/courseoffered/pscoptometry.php">PSC-OPTOMETRY</a>
        
         </center>
            </h4>  
  </div>		  
                </div>
            </div>
        </div>
    </div>


    <div class="navbar visible-lg">
        <ul>
            <li><a class="whatsapp" href="#"><i class="fa-brands
fa-whatsapp" style="color:#33F802" ></i> 91 8089085309</a></li>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <li><a href="#">HOME</a></li>
            <li><a href="#">COURSES <i class="fa-light
fa-angle-right" style="font-size:10px"></i></a>
                <ul class="sub-menu">
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> DHA</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> MOH</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> HAAD</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> PROMETRIC</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> CBT-UK</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> NCLEX-RN</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> PSC</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> AIIMS</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> ACLS</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> JIPMER</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> BLS</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> IELTS</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> PSC-PHARMACY</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> PSC-MICROBIOLOGY</a></li>
                    <li><a href="#"><i class="fa-light
fa-angle-right"></i> PSC-OPTOMETRY</a></li>
                </ul>
            </li>

            <li><a href="#">BATCH TIMES</a></li>
            <li><a href="#">ACHIEVEMENTS</a></li>
            <li><a href="#">REVIEWS</a></li>
            <li><a href="#">BLOG</a></li>
            <li><a href="#">CONTACT</a></li>
            <li><a class="green" href="#">START A COURSE</a></li>
        </ul>
    </div>